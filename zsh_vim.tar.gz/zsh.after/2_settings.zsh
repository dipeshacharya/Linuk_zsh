PATH=${HOME}/.local/bin:${PATH}

export PATH=$(awk -F: '{for(i=1;i<=NF;i++){if(!($i in a)){a[$i];printf s$i;s=":"}}}'<<<$PATH)
export LS_OPTIONS="--color=auto"
export HISTSIZE=10000000
export SAVEHIST=$HISTSIZE
export GREP_COLOR='1;33'
export EDITOR=vim
export VISUAL=vim
export TERM=xterm-256color


# Speedup path completion
zstyle ':completion:*' accept-exact '*(N)'
unsetopt no_match

alias git='noglob git'
alias rm='nocorrect rm'
alias zmv="noglob zmv -W"

# Global aliases
alias -g ...='../..'
alias -g ....='../../..'
alias -g .....='../../../..'

#Load themes from yadr and from user's custom prompts (themes) in ~/.zsh.prompts
autoload promptinit
fpath=($HOME/.zsh.prompts $fpath)
promptinit

# Makes git auto completion faster favouring for local completions
__git_files () {
    _wanted files expl 'local files' _files
}

bindkey -v                                          # Use vi key bindings

# Make numpad enter work
bindkey -s "^[Op" "0"
bindkey -s "^[Ol" "."
bindkey -s "^[OM" "^M"

# Use Ctrl-x,Ctrl-l to get the output of the last command
zmodload -i zsh/parameter
insert-last-command-output() {
        LBUFFER+="$(eval $history[$((HISTCMD-1))])"
}
zle -N insert-last-command-output
bindkey "^X^L" insert-last-command-output

if [ -e ~/.secrets ]; then
  source ~/.secrets
fi

autoload -U zmv

function fn() { ls **/*$1* }
