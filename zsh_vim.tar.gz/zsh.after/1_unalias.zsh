unaliasArray=(df gtr grc gcp gcP gdu gid giD gls gRm gwc gwC du gm)
unsetArray=(wdiff diff make)

for ALIAS in $unaliasArray; do
    unalias $ALIAS >/dev/null 2>&1
  done

  for FUNC in $unsetArray; do
    unset -f $FUNC >/dev/null 2>&1;
  done
#unsetopt nomatch
