alias git='noglob git'
alias rm='nocorrect rm'
alias zmv="noglob zmv -W"

# Global aliases
alias -g ...='../..'
alias -g ....='../../..'
alias -g .....='../../../..'

alias get='curl -L -O'
alias xc='xclip -selection clipboard -i'
alias urldecode='python -c "import sys, urllib as ul; print ul.unquote_plus(sys.stdin.read())"'
alias urlencode='python -c "import sys, urllib as ul; print ul.quote_plus(sys.stdin.read())"'
alias git_all='find . -type d -name .git -exec sh -c "cd \"{}\"/../ && pwd && git pull" \;'
alias ls='ls --color=tty'
alias l='ls -lah'
alias la='ls -lAh'
alias lld='ls -ltr ~/dump.log'
alias llh='ls -ltrh'
alias lll='ls -ltr'
alias lsa='ls -lah'
alias lh='ls -alt | head'
alias ll='ls -alh'
alias lsg='ll | grep'
alias grep='grep --color=auto'
export PROMPT_EOL_MARK=""
alias cols="python3 -c \"import sys,sqlite3;print('\n'.join([member[0] for member in sqlite3.connect(sys.argv[1]).cursor().execute('select * from {}'.format(sys.argv[2])).description]))\""
alias to_list="LANG=C cat | LANG=C awk -v q=\"'\" 'BEGIN{ORS=\",\"; printf \"[\";} \$1!=\"\"{ print q\$1q; } END{ printf \"]\"}'| LANG=C sed -e \"s/,\]\$/\]/g\" "
alias to_dict="LANG=C cat | LANG=C awk -v q=\"'\" 'BEGIN{ORS=\",\"; printf \"{\";} \$2!=\"\"{ print q\$1q\":\"q\$2q; } END{ printf \"}\"}'| LANG=C sed -e \"s/,\}\$/\}/g\" "
alias to_clause="LANG=C cat | LANG=C awk -v q=\"'\" 'BEGIN{ORS=\",\"; printf \"(\";} \$1!=\"\"{ print q\$0q; } END{ printf \")\"}'| LANG=C perl -pe \"s/,\)\$/\)/g\" "
alias to_clause_int="LANG=C cat | LANG=C awk -v q=\"'\" 'BEGIN{ORS=\",\"; printf \"(\";} \$1!=\"\"{ print \$1; } END{ printf \")\"}'| LANG=C perl -pe \"s/,\)\$/\)/g\" "
alias to_clause_regex="LANG=C cat | LANG=C awk -v q=\"'\" 'BEGIN{ORS=\"|\"; printf \"(\";} \$1!=\"\"{ print \$1; } END{ printf \")\"}'| LANG=C perl -pe \"s/\|\)\$/\)/g\" "
alias aria2='aria2c -s16 --max-connection-per-server=16 --min-split-size=1M '
alias svn_purge="svn status --no-ignore | grep -E '(^\?)|(^\I)' | sed -e 's/^. *//' | sed -e 's/\(.*\)/\"\1\"/' | xargs rm -rf"
export LESSOPEN="| highlight %s --out-format xterm256 --line-numbers --quiet --force --style navy"
export LESS=" -R"
alias lless='less -m -N -g -i -J --line-numbers --underline-special'
alias mmore='lless'
# Use "highlight" in place of "cat"
alias ccat="highlight $1 --out-format xterm256 --quiet --force --style navy"
alias lib="/sbin/ldconfig -p | awk -F '=> ' '\$0~/=>/{print \$2}' |awk -F'/[^/]*$' '!(\$1 in a) {a[\$1];printf(\"%s:\",\$1)}'"
alias bytes_hr="awk '{ split( \"B KB MB GB TB PB\" , v ); s=1; while( \$1>1024 ){ \$1/=1024; s++ } printf \"%.2f %s\", \$1, v[s] }'"
