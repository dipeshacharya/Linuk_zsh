##compdef apt-update-repo
function fn() { ls **/*$1* }
autoload -Uz bashcompinit && bashcompinit
apt-update-repo() {
sudo apt-get update -o Dir::Etc::sourcelist="sources.list.d/$1.list" \
    -o Dir::Etc::sourceparts="-" -o APT::Get::List-Cleanup="0"
 }

 function _apt_update_repo() {
     local cur 
     local -a list
     list=( `find /etc/apt/sources.list.d/ -name "*.list" -exec basename {} \; | sed 's/\.list$//g' 2> /dev/null` )
     local i=0
     local wc=${#list[@]}
     COMPREPLY=( $( compgen -W "${list[*]}" -- "$cur" ) )
 }
complete -F _apt_update_repo apt-update-repo
