if (( $+widgets[history-incremental-pattern-search-backward] )); then
  #bindkey -M vicmd '?'  history-incremental-pattern-search-forward
  bindkey -M viins '^F' history-incremental-pattern-search-forward
  bindkey -M viins '^N' history-incremental-pattern-search-backward
  bindkey -M vicmd '^R' history-incremental-pattern-search-backward
  bindkey -M vicmd '.'  history-incremental-pattern-search-backward
  bindkey -M vicmd '/' history-incremental-search-backward
  bindkey -M vicmd 'n' history-incremental-search-backward
  bindkey -M vicmd 'b' history-incremental-search-forward
else
  #bindkey -M vicmd '/' history-incremental-search-backward
  bindkey -M vicmd 'n' history-incremental-search-backward
  bindkey -M vicmd 'b' history-incremental-search-forward
fi
