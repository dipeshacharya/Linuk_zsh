export PATH=/opt/kubernetes/server/bin:$PATH
