#!/bin/bash

function compress {
  cd $HOME
  temp=/tmp/compress.$$
  cat << EOD > $temp
backup
swap
undo
viminfo
.cache
.vim/dein/cache_vim
state_vim.vim
tests/*
test/*
__pycache__
*.pyc
EOD
  echo tar --exclude-from=$temp -czf vimfiles.tar .vim .vimrc
  tar --exclude-from=$temp -czf vimfiles.tar .vim .vimrc
  tar -czf zsh_vim.tar.gz .zsh.after .zsh.prompts .zshrc vimfiles.tar package_zsh.sh
  rm $temp
}

function link {
  cd $HOME
  for i in zpreztorc zprofile zshenv ; do
    ln -s $HOME/.zprezto/runcoms/${i} $HOME/.${i};
  done
}

function clone {
  cd $HOME
  git clone --recursive https://github.com/sorin-ionescu/prezto.git .zprezto
  cd $HOME/.zprezto
  git submodule update --init --recursive
}

function install {
  cd $HOME
  echo "installing packages 'zsh vim python3 git pigz'"
  sudo apt-get update && sudo apt-get install zsh vim python3 git pigz -y
  echo "Extracing ZSH files"
  tar -xf zsh_vim.tar.gz -C $HOME
  echo "Extracing VIM files"
  tar -xf vimfiles.tar -C $HOME
  echo "Cloning zprezto for ZSH"
  clone
  echo "Linking zprezto"
  link
  echo "Setting ZSH as default shell."
  echo "chsh -s /bin/zsh"
  chsh -s /bin/zsh
  echo "Done!"
}

$*
