# Db2 Settings
if [ -e ~/sqllib/db2profile ]; then
  source ~/sqllib/db2profile
fi
